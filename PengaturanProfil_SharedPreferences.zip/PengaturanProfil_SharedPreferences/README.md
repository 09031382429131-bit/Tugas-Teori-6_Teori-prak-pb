# Pengaturan Profil - SharedPreferences

Tugas Pemrograman Android berdasarkan materi SharedPreferences.

Fitur:
- Menyimpan nama, email, bio, kota
- Menyimpan pilihan avatar (Int)
- Menyimpan mode gelap (Boolean)
- Menyimpan jumlah pembukaan aplikasi (Int)
- Tombol Simpan
- Tombol Hapus Semua Data
- Data tetap ada setelah aplikasi ditutup dan dibuka kembali
- File SharedPreferences: `profil_prefs.xml`

Package:
`com.example.pengaturanprofil`

Minimum SDK:
API 24 (Android 7.0)

Catatan:
Project tidak menyertakan folder `build/` atau `.idea/` agar ZIP tetap bersih. Buka folder ini melalui Android Studio, lalu lakukan Gradle Sync.
