package com.example.pengaturanprofil

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val NAMA_PREFS = "profil_prefs"

        private const val KEY_NAMA = "nama"
        private const val KEY_EMAIL = "email"
        private const val KEY_BIO = "bio"
        private const val KEY_KOTA = "kota"
        private const val KEY_AVATAR = "avatar"
        private const val KEY_GELAP = "mode_gelap"
        private const val KEY_JUMLAH_BUKA = "jumlah_buka"

        private val DAFTAR_AVATAR = listOf(
            R.drawable.avatar_1,
            R.drawable.avatar_2,
            R.drawable.avatar_3
        )
    }

    private val prefs by lazy {
        getSharedPreferences(NAMA_PREFS, MODE_PRIVATE)
    }

    private var indeksAvatar = 0

    private lateinit var layoutUtama: android.view.View
    private lateinit var ivAvatar: ImageView
    private lateinit var tvNamaKartu: TextView
    private lateinit var tvEmailKartu: TextView
    private lateinit var tvJumlahBuka: TextView
    private lateinit var etNama: EditText
    private lateinit var etEmail: EditText
    private lateinit var etBio: EditText
    private lateinit var etKota: EditText
    private lateinit var swGelap: SwitchCompat
    private lateinit var btnAvatar: Button
    private lateinit var btnSimpan: Button
    private lateinit var btnHapus: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        layoutUtama = findViewById(R.id.layoutUtama)
        ivAvatar = findViewById(R.id.ivAvatar)
        tvNamaKartu = findViewById(R.id.tvNamaKartu)
        tvEmailKartu = findViewById(R.id.tvEmailKartu)
        tvJumlahBuka = findViewById(R.id.tvJumlahBuka)
        etNama = findViewById(R.id.etNama)
        etEmail = findViewById(R.id.etEmail)
        etBio = findViewById(R.id.etBio)
        etKota = findViewById(R.id.etKota)
        swGelap = findViewById(R.id.swGelap)
        btnAvatar = findViewById(R.id.btnAvatar)
        btnSimpan = findViewById(R.id.btnSimpan)
        btnHapus = findViewById(R.id.btnHapus)

        // Setiap aplikasi dibuka, nilai jumlah_buka bertambah 1.
        val jumlahBukaBaru = prefs.getInt(KEY_JUMLAH_BUKA, 0) + 1
        prefs.edit().putInt(KEY_JUMLAH_BUKA, jumlahBukaBaru).apply()

        tampilkanDataTersimpan()
        tampilkanJumlahBuka(jumlahBukaBaru)

        btnAvatar.setOnClickListener {
            indeksAvatar = (indeksAvatar + 1) % DAFTAR_AVATAR.size
            ivAvatar.setImageResource(DAFTAR_AVATAR[indeksAvatar])
        }

        btnSimpan.setOnClickListener {
            simpanData()
        }

        btnHapus.setOnClickListener {
            hapusSemuaData()
        }

        swGelap.setOnCheckedChangeListener { _, isChecked ->
            if (!swGelap.isPressed) return@setOnCheckedChangeListener
            terapkanTampilan(isChecked)
            prefs.edit().putBoolean(KEY_GELAP, isChecked).apply()
        }
    }

    private fun simpanData() {
        val nama = etNama.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val bio = etBio.text.toString().trim()
        val kota = etKota.text.toString().trim()
        val modeGelap = swGelap.isChecked

        prefs.edit()
            .putString(KEY_NAMA, nama)
            .putString(KEY_EMAIL, email)
            .putString(KEY_BIO, bio)
            .putString(KEY_KOTA, kota)
            .putInt(KEY_AVATAR, indeksAvatar)
            .putBoolean(KEY_GELAP, modeGelap)
            .apply()

        tampilkanKartu(nama, email)
        terapkanTampilan(modeGelap)

        Toast.makeText(this, "Data profil berhasil disimpan", Toast.LENGTH_SHORT).show()
    }

    private fun tampilkanDataTersimpan() {
        val nama = prefs.getString(KEY_NAMA, "") ?: ""
        val email = prefs.getString(KEY_EMAIL, "") ?: ""
        val bio = prefs.getString(KEY_BIO, "") ?: ""
        val kota = prefs.getString(KEY_KOTA, "") ?: ""
        indeksAvatar = prefs.getInt(KEY_AVATAR, 0).coerceIn(0, DAFTAR_AVATAR.lastIndex)
        val modeGelap = prefs.getBoolean(KEY_GELAP, false)

        etNama.setText(nama)
        etEmail.setText(email)
        etBio.setText(bio)
        etKota.setText(kota)
        swGelap.isChecked = modeGelap
        ivAvatar.setImageResource(DAFTAR_AVATAR[indeksAvatar])

        tampilkanKartu(nama, email)
        terapkanTampilan(modeGelap)
    }

    private fun tampilkanKartu(nama: String, email: String) {
        tvNamaKartu.text = if (nama.isBlank()) "Nama Pengguna" else nama
        tvEmailKartu.text = if (email.isBlank()) "email@contoh.com" else email
    }

    private fun tampilkanJumlahBuka(jumlah: Int) {
        tvJumlahBuka.text = "Kamu sudah membuka aplikasi ini $jumlah kali."
    }

    private fun terapkanTampilan(modeGelap: Boolean) {
        if (modeGelap) {
            layoutUtama.setBackgroundColor(Color.rgb(28, 28, 30))
            tvNamaKartu.setTextColor(Color.WHITE)
            tvEmailKartu.setTextColor(Color.LTGRAY)
            tvJumlahBuka.setTextColor(Color.WHITE)
        } else {
            layoutUtama.setBackgroundColor(Color.rgb(245, 247, 250))
            tvNamaKartu.setTextColor(Color.rgb(33, 33, 33))
            tvEmailKartu.setTextColor(Color.DKGRAY)
            tvJumlahBuka.setTextColor(Color.rgb(33, 33, 33))
        }
    }

    private fun hapusSemuaData() {
        prefs.edit().clear().apply()

        etNama.setText("")
        etEmail.setText("")
        etBio.setText("")
        etKota.setText("")
        indeksAvatar = 0
        ivAvatar.setImageResource(DAFTAR_AVATAR[indeksAvatar])
        swGelap.isChecked = false

        tampilkanKartu("", "")
        tampilkanJumlahBuka(0)
        terapkanTampilan(false)

        Toast.makeText(this, "Semua data berhasil dihapus", Toast.LENGTH_SHORT).show()
    }
}
